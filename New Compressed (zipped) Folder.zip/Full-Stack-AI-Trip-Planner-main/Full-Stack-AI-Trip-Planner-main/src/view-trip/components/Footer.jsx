import React from 'react'

function Footer() {
  return (
    <div className='my-6'>
      <h2 className='text-gray-400 text-center'>Created by Öykü Kaya Ai Travel Planner App    </h2>
    </div>
  )
}

export default Footer
